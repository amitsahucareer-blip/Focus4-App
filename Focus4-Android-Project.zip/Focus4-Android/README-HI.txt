FOCUS 4 — Android Studio Project

यह Android ऐप का source project है। इस environment में Android SDK/Gradle उपलब्ध न होने के कारण तैयार APK compile नहीं किया गया है। इस project को Android Studio में खोलकर APK बनाया जा सकता है।

APK बनाने के चरण:
1. कंप्यूटर पर Android Studio स्थापित करें।
2. Android Studio > Open चुनें और यह पूरा 'Focus4-Android' folder खोलें।
3. Gradle Sync पूरा होने दें और Android SDK Platform 35 स्थापित करें (यदि पूछा जाए)।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK आमतौर पर app/build/outputs/apk/debug/app-debug.apk में मिलेगा।
6. APK को अपने Android फोन में भेजकर इंस्टॉल करें। फोन में पहली बार unknown apps install करने की अनुमति देनी पड़ सकती है।

ध्यान दें:
- यह शुरुआती WebView आधारित Android wrapper है; ऐप का डेटा फोन के ऐप storage में रहता है।
- ऐप uninstall या app data clear करने पर local data हट सकता है। PDF की बड़ी फाइलें जोड़ने पर storage बढ़ेगा।
- यह debug APK होगा; Play Store पर प्रकाशित करने के लिए signed release build और अतिरिक्त परीक्षण जरूरी हैं।
